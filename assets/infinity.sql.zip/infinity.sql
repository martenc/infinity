-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 15, 2013 at 07:37 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `infinity`
--

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE IF NOT EXISTS `project` (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for a Project.',
  `name` varchar(255) NOT NULL COMMENT 'Project Description',
  `client` int(11) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Saves Project details' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `timesheet`
--

CREATE TABLE IF NOT EXISTS `timesheet` (
  `tid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for a Timesheet.',
  `pid` int(11) NOT NULL COMMENT 'Project ID.',
  `uid` int(11) NOT NULL COMMENT 'The users.uid that owns this timesheet; initially, this is the user that created it.',
  `description` varchar(255) DEFAULT NULL,
  `created` int(8) DEFAULT NULL COMMENT 'The Unix tiamestamp when the Timesheet was created.',
  `ended` int(8) DEFAULT NULL COMMENT 'The Unix tiamestamp when the Timesheet was ended.',
  `total` int(11) DEFAULT NULL COMMENT 'Total timesheet time in seconds',
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'user unique id',
  `email` int(128) NOT NULL COMMENT 'user email address',
  `password` varchar(128) NOT NULL COMMENT 'user password sha hash',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='User table' AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
